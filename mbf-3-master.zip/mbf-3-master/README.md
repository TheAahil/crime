# mbf v3

Update crack from requests friends

![20201014_171639](https://user-images.githubusercontent.com/66865892/95977463-71667780-0e08-11eb-9b96-0f7ab7fa057a.jpg)


Cara install

$pkg update && pkg upgrade

$pkg install git curl python

$pkg install ruby

$gem install lolcat

$termux-setup-storage

$pip install mechanize requests bs4 futures

$pip install colorama

$git clone https://github.com/BladeKnife/mbf

$cd mbf

$python fb.py
